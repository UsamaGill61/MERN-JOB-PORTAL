export const api = "http://localhost:5000/api";


export const generatePublicUrl = (filename) => {
    return `http://localhost:5000/public/${filename}`;
  };
