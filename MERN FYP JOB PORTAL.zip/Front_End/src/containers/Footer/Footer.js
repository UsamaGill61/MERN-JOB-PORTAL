import React, { Component } from 'react'
import './Footer.css'

 class Footer extends Component {
    render() {
        return (
            <div className="container-fluid ">
                <div className="row background  text-center">
                    <div className="col my-1">
                    <p className="footer-text mb-4">@ Designed & Built by Muhammad Usama</p>
                    </div>
                    
                    </div> 
            
            </div>
        )
    }
}

export default Footer
