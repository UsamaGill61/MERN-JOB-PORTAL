export const experienceRequiredDropDownValues = [
  { key: "Experience ", value: "" },
  { key: "0 - 1 Year", value: "0 - 1" },
  { key: "1 - 2 Year", value: "1 - 2" },
  { key: "2 - 3 Year", value: "2 - 3" },
  { key: "3 - 4 Year", value: "3 - 4" },
  { key: "4 - 5 Year", value: "4 - 5" },
  { key: "More than 5 years Year", value: "More than 5 years" },
];
export const employmentStatusDropDownValues = [
    { key: "Select Employment Status", value: "" },
    { key: "Temporary", value: "Temporary" },
    { key: "Contract", value: "Contract" },
    { key: "Permanent/Fulltime", value: "Permanent/Fulltime" },
  ];
  export const genderDropDownValues = [
    { key: "Select Gender ", value: "" },
    { key: "Male", value: "Male" },
    { key: "Female", value: "Female" },
    { key: "Male/Female", value: "Male/Female" },
  ];
  export const genderDropDownValues2options = [
    { key: "Select Gender ", value: "" },
    { key: "Male", value: "Male" },
    { key: "Female", value: "Female" },
  ];
  export const AgeDownValues = [
    { key: "Select Age ", value: "" },
    { key: "18 - 30", value: "18 - 30" },
    { key: "30 - 40", value: "30 - 40" },
    { key: "40 - 50", value: "40 - 50" },
    { key: "Above 50", value: "Above 50" },

  ];
  export const DegreeLevelValues = [
    { key: "Select Degree Level ", value: "" },
    { key: "Associate Degree", value: "Associate Degree" },
    { key: "Bachelor's Degree", value: "Bachelor's Degree" },
    { key: "Master's Degree", value: "Master's Degree" },
    { key: "Doctoral Degree", value: "Doctoral Degree" },

  ];
  export const maritalStatusValues = [
    {key:"Select Martial Status",value:""},
    {key:"Single",value:"Single"},
    {key:"Married",value:"Married"},

  ]